
from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'Dojo'

@app.route('/')
def index():
    session.clear()
    return render_template('index.html')

@app.route('/submit', methods=['post'])
def submit():
    session['name'] = request.form['name']
    session['city'] = request.form['city']
    session['stack'] = request.form['stack']
    session['comment'] = request.form['comment']
    return redirect('/result')


@app.route('/result')
def result():
    return render_template('results.html')





if __name__=="__main__":
    app.run(debug=True) 